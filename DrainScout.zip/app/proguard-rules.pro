# Keep it simple.
-keepattributes *Annotation*
-keep class rikka.shizuku.** { *; }
