package com.drain.scout

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val BgDark = Color(0xFF07131B)
private val BgPanel = Color(0xFF0E1E2A)
private val TextPrimary = Color(0xFFE6F3FF)
private val TextSecondary = Color(0xFF9CC8FF)
private val TextMuted = Color(0xFF9BB0BF)
private val Success = Color(0xFF8AE6C9)
private val Warning = Color(0xFFFFCF78)
private val ErrorColor = Color(0xFFFFB4B4)

internal data class DiagnosticsUiState(
    val hasPermission: Boolean = false,
    val loading: Boolean = false,
    val snapshot: DiagnosticSnapshot? = null,
    val error: String? = null
)

internal class DrainScoutViewModel : ViewModel() {
    private val _state = MutableStateFlow(DiagnosticsUiState())
    val state: StateFlow<DiagnosticsUiState> = _state.asStateFlow()

    fun refreshPermissionState() {
        _state.value = _state.value.copy(hasPermission = DiagnosticEngine.hasShellPermission())
    }

    fun captureSnapshot() {
        if (_state.value.loading) return
        _state.value = _state.value.copy(loading = true, error = null)
        viewModelScope.launch {
            try {
                val snapshot = withContext(Dispatchers.IO) { DiagnosticEngine.collectSnapshot() }
                _state.value = _state.value.copy(
                    loading = false,
                    snapshot = snapshot,
                    hasPermission = snapshot.permissionStatus == DiagnosticEngine.PERMISSION_OK_LABEL,
                    error = null
                )
            } catch (t: Throwable) {
                _state.value = _state.value.copy(
                    loading = false,
                    error = t.message ?: "Capture failed."
                )
            }
        }
    }
}

private enum class TabSpec(val title: String) {
    OVERVIEW("Overview"),
    WAKELOCKS("Wakelocks"),
    ALARMS("Alarms"),
    IDLE("Idle"),
    REPORT("Report")
}

@Composable
internal fun DrainScoutApp(
    viewModel: DrainScoutViewModel,
    onRequestShizuku: () -> Unit,
    onShare: (String) -> Unit
) {
    val state by viewModel.state.collectAsState()
    val clipboard = LocalClipboardManager.current
    val snapshot = state.snapshot
    val report = snapshot?.toReport().orEmpty()
    val findings = remember(snapshot) { snapshot?.let(DiagnosticEngine::summarizeFindings).orEmpty() }
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = TabSpec.values()

    LaunchedEffect(Unit) {
        viewModel.refreshPermissionState()
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = BgDark,
            surface = BgDark,
            onBackground = TextPrimary,
            onSurface = TextPrimary,
            primary = Success,
            onPrimary = BgDark
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = BgDark) {
            Column(modifier = Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("DrainScout", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
                    Text("Idle drain investigation", color = TextSecondary)
                    Text(
                        text = if (state.hasPermission) "Shizuku shell ready" else "Shizuku permission required",
                        color = if (state.hasPermission) Success else Warning
                    )

                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (!state.hasPermission) {
                            Button(onClick = onRequestShizuku) { Text("Connect Shizuku") }
                        }
                        Button(onClick = viewModel::captureSnapshot, enabled = !state.loading) {
                            Text(if (state.loading) "Capturing…" else "Capture baseline")
                        }
                        if (snapshot != null) {
                            Button(onClick = { clipboard.setText(AnnotatedString(report)) }) { Text("Copy") }
                            Button(onClick = { onShare(report) }) { Text("Share") }
                        }
                    }

                    state.error?.let { Text(it, color = ErrorColor) }
                    snapshot?.let { Text("Last capture: ${it.capturedAt}", color = TextMuted) }
                }

                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = BgDark,
                    contentColor = Success,
                    edgePadding = 12.dp
                ) {
                    tabs.forEachIndexed { index, tab ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = { Text(tab.title) }
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (snapshot == null) {
                        PanelText("No capture yet. Connect Shizuku, then tap Capture baseline.")
                    } else {
                        when (tabs[selectedTab]) {
                            TabSpec.OVERVIEW -> findings.forEach { FindingCard(it) }
                            TabSpec.WAKELOCKS -> PanelText(snapshot.power, mono = true)
                            TabSpec.ALARMS -> PanelText(snapshot.alarms, mono = true)
                            TabSpec.IDLE -> PanelText(snapshot.deviceIdle, mono = true)
                            TabSpec.REPORT -> PanelText(report, mono = true)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FindingCard(finding: Finding) {
    val accent = when (finding.severity) {
        Severity.INFO -> Success
        Severity.WATCH -> Warning
        Severity.LIKELY -> ErrorColor
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = BgPanel)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(finding.title, color = accent, style = MaterialTheme.typography.titleMedium)
            Text(finding.detail, color = TextPrimary)
        }
    }
}

@Composable
private fun PanelText(text: String, mono: Boolean = false) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = BgPanel)
    ) {
        Text(
            text = text,
            color = TextPrimary,
            fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default,
            fontSize = if (mono) 12.sp else 14.sp,
            modifier = Modifier.fillMaxWidth().background(BgPanel).padding(14.dp)
        )
    }
}
