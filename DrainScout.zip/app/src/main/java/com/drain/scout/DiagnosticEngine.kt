package com.drain.scout

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.time.Instant
import java.util.concurrent.TimeUnit

internal data class DiagnosticSnapshot(
    val battery: String,
    val power: String,
    val alarms: String,
    val deviceIdle: String,
    val capturedAt: Instant,
    val permissionStatus: String
) {
    fun toReport(): String = buildString {
        appendLine("DrainScout report")
        appendLine("Captured: $capturedAt")
        appendLine("Permission status: $permissionStatus")
        appendLine("Interpretation: treat this as triage evidence, not final causation.")
        appendLine()
        appendLine("== Battery ==")
        appendLine(battery.ifBlank { "No output returned." })
        appendLine()
        appendLine("== Power / wakelocks ==")
        appendLine(power.ifBlank { "No output returned." })
        appendLine()
        appendLine("== Alarms ==")
        appendLine(alarms.ifBlank { "No output returned." })
        appendLine()
        appendLine("== Device idle ==")
        appendLine(deviceIdle.ifBlank { "No output returned." })
    }
}

internal enum class Severity { INFO, WATCH, LIKELY }

internal data class Finding(val title: String, val detail: String, val severity: Severity)

internal object DiagnosticEngine {
    private const val GRANTED_LABEL = "Shizuku-authorized shell"
    private const val DENIED_LABEL = "No shell permission"
    private const val UNAVAILABLE = "Command unavailable in this execution context."

    const val PERMISSION_OK_LABEL = GRANTED_LABEL

    fun hasShellPermission(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) {
        false
    }

    fun collectSnapshot(): DiagnosticSnapshot {
        val allowed = hasShellPermission()
        val permissionStatus = if (allowed) GRANTED_LABEL else DENIED_LABEL

        val battery = if (allowed) runCommand("dumpsys", "batterystats", "--charged") else UNAVAILABLE
        val power = if (allowed) runCommand("dumpsys", "power") else UNAVAILABLE
        val alarms = if (allowed) runCommand("dumpsys", "alarm") else UNAVAILABLE
        val idle = if (allowed) runCommand("dumpsys", "deviceidle") else UNAVAILABLE

        return DiagnosticSnapshot(
            battery = summarize(battery, listOf("Estimated power", "Uid", "wake", "screen", "Statistics since")),
            power = summarize(power, listOf("wake lock", "wakelock", "suspend blocker", "mWakefulness", "PARTIAL_WAKE_LOCK", "held")),
            alarms = summarize(alarms, listOf("Alarm Stats", "PendingIntent", "RTC_WAKEUP", "ELAPSED_REALTIME_WAKEUP", "whenElapsed")),
            deviceIdle = summarize(idle, listOf("mState=", "mLightState=", "IDLE", "mScreenOn", "mCharging")),
            capturedAt = Instant.now(),
            permissionStatus = permissionStatus
        )
    }

    fun summarizeFindings(snapshot: DiagnosticSnapshot): List<Finding> = buildList {
        val powerText = snapshot.power
        val alarmsText = snapshot.alarms
        val idleText = snapshot.deviceIdle

        if (powerText.contains("wake", true) || powerText.contains("wakelock", true)) {
            add(Finding("Potential wake-lock activity", "Power output contains wake-related lines. This is a signal to inspect the exact owner and duration, not proof of root cause.", Severity.WATCH))
        } else {
            add(Finding("No obvious wake-lock signal", "The filtered output did not match common wakelock markers. Device-specific formatting may hide them.", Severity.INFO))
        }

        if (alarmsText.contains("Alarm Stats", true) || alarmsText.contains("PendingIntent", true) || alarmsText.contains("WAKEUP", true)) {
            add(Finding("Alarm traffic detected", "Alarm-related lines appeared in the snapshot. Repeating alarms can contribute to idle drain, especially during screen-off time.", Severity.WATCH))
        } else {
            add(Finding("No alarm signal matched", "No obvious alarm summary lines appeared in the filtered result. This could be vendor-specific output.", Severity.INFO))
        }

        if (idleText.contains("IDLE", true) || idleText.contains("mState=", true)) {
            add(Finding("Idle state visible", "The device-idle dump returned state markers, which helps confirm the collection happened during idle or low-activity conditions.", Severity.INFO))
        } else {
            add(Finding("Idle-state visibility weak", "No common idle markers showed up in the filtered result. Compare multiple captures for confidence.", Severity.WATCH))
        }

        add(Finding("Best comparison method", "Capture at the same battery level and screen-off interval, then compare two or more snapshots before drawing conclusions.", Severity.INFO))
    }

    /**
     * Shizuku.newProcess is private since API 13.1, so it is invoked reflectively.
     * Stdout is drained on a separate thread so large dumpsys output cannot fill the pipe and deadlock.
     */
    private fun runCommand(vararg args: String): String = try {
        val method = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        method.isAccessible = true
        val process = method.invoke(null, arrayOf(*args), null, null) as Process

        var output = ""
        val reader = Thread {
            output = try {
                process.inputStream.bufferedReader().use { it.readText() }
            } catch (_: Throwable) {
                ""
            }
        }
        reader.start()

        val completed = process.waitFor(25, TimeUnit.SECONDS)
        if (!completed) process.destroy()
        reader.join(2_000)
        output.ifBlank { UNAVAILABLE }
    } catch (_: Throwable) {
        UNAVAILABLE
    }

    private fun summarize(raw: String, patterns: List<String>): String {
        val normalized = raw.ifBlank { "No output returned." }
        val selected = normalized.lineSequence()
            .filter { line -> patterns.any { pattern -> line.contains(pattern, ignoreCase = true) } }
            .take(80)
            .toList()

        return if (selected.isEmpty()) {
            "No common summary lines matched this device output. Output may use different wording or filtering may be too strict."
        } else {
            selected.joinToString("\n").take(12000)
        }
    }
}
